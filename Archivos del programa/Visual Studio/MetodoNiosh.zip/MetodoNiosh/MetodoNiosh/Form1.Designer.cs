﻿namespace MetodoNiosh
{
    partial class HojaDeTrabajoNiosh
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(HojaDeTrabajoNiosh));
            this.BotonGuardarImagen = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.comboBoxRWLDestino = new System.Windows.Forms.ComboBox();
            this.comboBoxRWLOrigen = new System.Windows.Forms.ComboBox();
            this.btnL = new System.Windows.Forms.Button();
            this.btnVM = new System.Windows.Forms.Button();
            this.btnDM = new System.Windows.Forms.Button();
            this.btnAM = new System.Windows.Forms.Button();
            this.btnHM = new System.Windows.Forms.Button();
            this.btnLC = new System.Windows.Forms.Button();
            this.btnA = new System.Windows.Forms.Button();
            this.btnD = new System.Windows.Forms.Button();
            this.btnV = new System.Windows.Forms.Button();
            this.btnH = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.chkBLMax = new System.Windows.Forms.CheckBox();
            this.chkBLProm = new System.Windows.Forms.CheckBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtBUbicacionManoSistema = new System.Windows.Forms.TextBox();
            this.txtBDistanciaVerticalSistema = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.CM = new System.Windows.Forms.Button();
            this.btnFM = new System.Windows.Forms.Button();
            this.txtBIndiceElevacionDestino = new System.Windows.Forms.TextBox();
            this.txtBIndiceElevacionOrigen = new System.Windows.Forms.TextBox();
            this.txtBIndiceElevacionDestinoRWL = new System.Windows.Forms.TextBox();
            this.txtBIndiceElevacionOrigenRWL = new System.Windows.Forms.TextBox();
            this.txtBIndiceElevacionDestinoPesoObjetoL = new System.Windows.Forms.TextBox();
            this.txtBIndiceElevacionOrigenPesoObjetoL = new System.Windows.Forms.TextBox();
            this.txtBPesoObjetoSistema = new System.Windows.Forms.TextBox();
            this.txtBDestinoRWL = new System.Windows.Forms.TextBox();
            this.txtBOrigenRWL = new System.Windows.Forms.TextBox();
            this.txtCMDestino = new System.Windows.Forms.TextBox();
            this.txtFMDestino = new System.Windows.Forms.TextBox();
            this.txtBDestinoAM = new System.Windows.Forms.TextBox();
            this.txtBDestinoDM = new System.Windows.Forms.TextBox();
            this.txtBDestinoVM = new System.Windows.Forms.TextBox();
            this.txtBDestinoHM = new System.Windows.Forms.TextBox();
            this.txtBDestinoLC = new System.Windows.Forms.TextBox();
            this.txtCMOrigen = new System.Windows.Forms.TextBox();
            this.txtFMOrigen = new System.Windows.Forms.TextBox();
            this.txtBOrigenAM = new System.Windows.Forms.TextBox();
            this.txtBOrigenDM = new System.Windows.Forms.TextBox();
            this.txtBOrigenVM = new System.Windows.Forms.TextBox();
            this.txtBOrigenHM = new System.Windows.Forms.TextBox();
            this.txtBOrigenLC = new System.Windows.Forms.TextBox();
            this.txtBAcoplamientoObjetos = new System.Windows.Forms.TextBox();
            this.txtBDuracion = new System.Windows.Forms.TextBox();
            this.txtBFrecuencia = new System.Windows.Forms.TextBox();
            this.txtBAnguloAsimetricoDestinoA = new System.Windows.Forms.TextBox();
            this.txtBAnguloAsimetricoOrigenA = new System.Windows.Forms.TextBox();
            this.txtBUbicacionManoDestinoV = new System.Windows.Forms.TextBox();
            this.txtBUbicacionManoDestinoH = new System.Windows.Forms.TextBox();
            this.txtBUbicacionManoOrigenV = new System.Windows.Forms.TextBox();
            this.txtBUbicacionManoOrigenH = new System.Windows.Forms.TextBox();
            this.txtBDistanciaVerticalD = new System.Windows.Forms.TextBox();
            this.txtBPesoObjetoLMax = new System.Windows.Forms.TextBox();
            this.txtBPesoObjetoLProm = new System.Windows.Forms.TextBox();
            this.txtBDescripcionDelTrabajo = new System.Windows.Forms.TextBox();
            this.txtBFecha = new System.Windows.Forms.TextBox();
            this.txtBNombreAnalista = new System.Windows.Forms.TextBox();
            this.txtBTituloProfesional = new System.Windows.Forms.TextBox();
            this.txtBDepartamento = new System.Windows.Forms.TextBox();
            this.btnCalcularResultado = new System.Windows.Forms.Button();
            this.btnRefrescar = new System.Windows.Forms.Button();
            this.btnInvertir = new System.Windows.Forms.Button();
            this.chkBSistemaInternacional = new System.Windows.Forms.CheckBox();
            this.chkBSistemaIngles = new System.Windows.Forms.CheckBox();
            this.btnLimpiar = new System.Windows.Forms.Button();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.botonGuardarExcel = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // BotonGuardarImagen
            // 
            this.BotonGuardarImagen.Location = new System.Drawing.Point(1158, 12);
            this.BotonGuardarImagen.Name = "BotonGuardarImagen";
            this.BotonGuardarImagen.Size = new System.Drawing.Size(165, 23);
            this.BotonGuardarImagen.TabIndex = 1;
            this.BotonGuardarImagen.Text = "Guardar informacion en imagen";
            this.BotonGuardarImagen.UseVisualStyleBackColor = true;
            this.BotonGuardarImagen.Click += new System.EventHandler(this.button3_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("groupBox1.BackgroundImage")));
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.comboBoxRWLDestino);
            this.groupBox1.Controls.Add(this.comboBoxRWLOrigen);
            this.groupBox1.Controls.Add(this.btnL);
            this.groupBox1.Controls.Add(this.btnVM);
            this.groupBox1.Controls.Add(this.btnDM);
            this.groupBox1.Controls.Add(this.btnAM);
            this.groupBox1.Controls.Add(this.btnHM);
            this.groupBox1.Controls.Add(this.btnLC);
            this.groupBox1.Controls.Add(this.btnA);
            this.groupBox1.Controls.Add(this.btnD);
            this.groupBox1.Controls.Add(this.btnV);
            this.groupBox1.Controls.Add(this.btnH);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.chkBLMax);
            this.groupBox1.Controls.Add(this.chkBLProm);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.txtBUbicacionManoSistema);
            this.groupBox1.Controls.Add(this.txtBDistanciaVerticalSistema);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.CM);
            this.groupBox1.Controls.Add(this.btnFM);
            this.groupBox1.Controls.Add(this.txtBIndiceElevacionDestino);
            this.groupBox1.Controls.Add(this.txtBIndiceElevacionOrigen);
            this.groupBox1.Controls.Add(this.txtBIndiceElevacionDestinoRWL);
            this.groupBox1.Controls.Add(this.txtBIndiceElevacionOrigenRWL);
            this.groupBox1.Controls.Add(this.txtBIndiceElevacionDestinoPesoObjetoL);
            this.groupBox1.Controls.Add(this.txtBIndiceElevacionOrigenPesoObjetoL);
            this.groupBox1.Controls.Add(this.txtBPesoObjetoSistema);
            this.groupBox1.Controls.Add(this.txtBDestinoRWL);
            this.groupBox1.Controls.Add(this.txtBOrigenRWL);
            this.groupBox1.Controls.Add(this.txtCMDestino);
            this.groupBox1.Controls.Add(this.txtFMDestino);
            this.groupBox1.Controls.Add(this.txtBDestinoAM);
            this.groupBox1.Controls.Add(this.txtBDestinoDM);
            this.groupBox1.Controls.Add(this.txtBDestinoVM);
            this.groupBox1.Controls.Add(this.txtBDestinoHM);
            this.groupBox1.Controls.Add(this.txtBDestinoLC);
            this.groupBox1.Controls.Add(this.txtCMOrigen);
            this.groupBox1.Controls.Add(this.txtFMOrigen);
            this.groupBox1.Controls.Add(this.txtBOrigenAM);
            this.groupBox1.Controls.Add(this.txtBOrigenDM);
            this.groupBox1.Controls.Add(this.txtBOrigenVM);
            this.groupBox1.Controls.Add(this.txtBOrigenHM);
            this.groupBox1.Controls.Add(this.txtBOrigenLC);
            this.groupBox1.Controls.Add(this.txtBAcoplamientoObjetos);
            this.groupBox1.Controls.Add(this.txtBDuracion);
            this.groupBox1.Controls.Add(this.txtBFrecuencia);
            this.groupBox1.Controls.Add(this.txtBAnguloAsimetricoDestinoA);
            this.groupBox1.Controls.Add(this.txtBAnguloAsimetricoOrigenA);
            this.groupBox1.Controls.Add(this.txtBUbicacionManoDestinoV);
            this.groupBox1.Controls.Add(this.txtBUbicacionManoDestinoH);
            this.groupBox1.Controls.Add(this.txtBUbicacionManoOrigenV);
            this.groupBox1.Controls.Add(this.txtBUbicacionManoOrigenH);
            this.groupBox1.Controls.Add(this.txtBDistanciaVerticalD);
            this.groupBox1.Controls.Add(this.txtBPesoObjetoLMax);
            this.groupBox1.Controls.Add(this.txtBPesoObjetoLProm);
            this.groupBox1.Controls.Add(this.txtBDescripcionDelTrabajo);
            this.groupBox1.Controls.Add(this.txtBFecha);
            this.groupBox1.Controls.Add(this.txtBNombreAnalista);
            this.groupBox1.Controls.Add(this.txtBTituloProfesional);
            this.groupBox1.Controls.Add(this.txtBDepartamento);
            this.groupBox1.Location = new System.Drawing.Point(0, 41);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1334, 796);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "groupBox1";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(1112, 489);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(52, 13);
            this.label7.TabIndex = 69;
            this.label7.Text = "Unidades";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(1112, 425);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(52, 13);
            this.label6.TabIndex = 68;
            this.label6.Text = "Unidades";
            // 
            // comboBoxRWLDestino
            // 
            this.comboBoxRWLDestino.FormattingEnabled = true;
            this.comboBoxRWLDestino.Items.AddRange(new object[] {
            ""});
            this.comboBoxRWLDestino.Location = new System.Drawing.Point(1110, 505);
            this.comboBoxRWLDestino.Name = "comboBoxRWLDestino";
            this.comboBoxRWLDestino.Size = new System.Drawing.Size(79, 21);
            this.comboBoxRWLDestino.TabIndex = 67;
            // 
            // comboBoxRWLOrigen
            // 
            this.comboBoxRWLOrigen.FormattingEnabled = true;
            this.comboBoxRWLOrigen.Location = new System.Drawing.Point(1110, 443);
            this.comboBoxRWLOrigen.Name = "comboBoxRWLOrigen";
            this.comboBoxRWLOrigen.Size = new System.Drawing.Size(79, 21);
            this.comboBoxRWLOrigen.TabIndex = 66;
            this.comboBoxRWLOrigen.Click += new System.EventHandler(this.comboBoxRWLOrigen_Click);
            // 
            // btnL
            // 
            this.btnL.Location = new System.Drawing.Point(55, 267);
            this.btnL.Name = "btnL";
            this.btnL.Size = new System.Drawing.Size(18, 19);
            this.btnL.TabIndex = 64;
            this.btnL.Text = "L";
            this.btnL.UseVisualStyleBackColor = true;
            this.btnL.Click += new System.EventHandler(this.btnL_Click);
            // 
            // btnVM
            // 
            this.btnVM.Location = new System.Drawing.Point(555, 399);
            this.btnVM.Name = "btnVM";
            this.btnVM.Size = new System.Drawing.Size(75, 39);
            this.btnVM.TabIndex = 63;
            this.btnVM.Text = "VM";
            this.btnVM.UseVisualStyleBackColor = true;
            this.btnVM.Click += new System.EventHandler(this.btnVM_Click);
            // 
            // btnDM
            // 
            this.btnDM.Location = new System.Drawing.Point(638, 399);
            this.btnDM.Name = "btnDM";
            this.btnDM.Size = new System.Drawing.Size(75, 39);
            this.btnDM.TabIndex = 62;
            this.btnDM.Text = "DM";
            this.btnDM.UseVisualStyleBackColor = true;
            this.btnDM.Click += new System.EventHandler(this.btnDM_Click);
            // 
            // btnAM
            // 
            this.btnAM.Location = new System.Drawing.Point(728, 399);
            this.btnAM.Name = "btnAM";
            this.btnAM.Size = new System.Drawing.Size(75, 39);
            this.btnAM.TabIndex = 61;
            this.btnAM.Text = "AM";
            this.btnAM.UseVisualStyleBackColor = true;
            this.btnAM.Click += new System.EventHandler(this.btnAM_Click);
            // 
            // btnHM
            // 
            this.btnHM.Location = new System.Drawing.Point(465, 399);
            this.btnHM.Name = "btnHM";
            this.btnHM.Size = new System.Drawing.Size(75, 39);
            this.btnHM.TabIndex = 60;
            this.btnHM.Text = "HM";
            this.btnHM.UseVisualStyleBackColor = true;
            this.btnHM.Click += new System.EventHandler(this.btnHM_Click);
            // 
            // btnLC
            // 
            this.btnLC.Location = new System.Drawing.Point(377, 399);
            this.btnLC.Name = "btnLC";
            this.btnLC.Size = new System.Drawing.Size(75, 39);
            this.btnLC.TabIndex = 59;
            this.btnLC.Text = "LC";
            this.btnLC.UseVisualStyleBackColor = true;
            this.btnLC.Click += new System.EventHandler(this.btnLC_Click);
            // 
            // btnA
            // 
            this.btnA.Location = new System.Drawing.Point(710, 269);
            this.btnA.Name = "btnA";
            this.btnA.Size = new System.Drawing.Size(31, 19);
            this.btnA.TabIndex = 58;
            this.btnA.Text = "A";
            this.btnA.UseVisualStyleBackColor = true;
            this.btnA.Click += new System.EventHandler(this.btnA_Click);
            // 
            // btnD
            // 
            this.btnD.Location = new System.Drawing.Point(570, 269);
            this.btnD.Name = "btnD";
            this.btnD.Size = new System.Drawing.Size(31, 19);
            this.btnD.TabIndex = 57;
            this.btnD.Text = "D";
            this.btnD.UseVisualStyleBackColor = true;
            this.btnD.Click += new System.EventHandler(this.btnD_Click);
            // 
            // btnV
            // 
            this.btnV.Location = new System.Drawing.Point(339, 267);
            this.btnV.Name = "btnV";
            this.btnV.Size = new System.Drawing.Size(31, 19);
            this.btnV.TabIndex = 56;
            this.btnV.Text = "V";
            this.btnV.UseVisualStyleBackColor = true;
            this.btnV.Click += new System.EventHandler(this.btnV_Click);
            // 
            // btnH
            // 
            this.btnH.Location = new System.Drawing.Point(277, 267);
            this.btnH.Name = "btnH";
            this.btnH.Size = new System.Drawing.Size(31, 19);
            this.btnH.TabIndex = 55;
            this.btnH.Text = "H";
            this.btnH.UseVisualStyleBackColor = true;
            this.btnH.Click += new System.EventHandler(this.btnH_Click_1);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Arial Black", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(778, 738);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(63, 18);
            this.label5.TabIndex = 54;
            this.label5.Text = "Destino";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial Black", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(778, 674);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(56, 18);
            this.label4.TabIndex = 53;
            this.label4.Text = "Origen";
            // 
            // chkBLMax
            // 
            this.chkBLMax.AutoSize = true;
            this.chkBLMax.Location = new System.Drawing.Point(822, 610);
            this.chkBLMax.Name = "chkBLMax";
            this.chkBLMax.Size = new System.Drawing.Size(63, 17);
            this.chkBLMax.TabIndex = 52;
            this.chkBLMax.Text = "L (máx.)";
            this.chkBLMax.UseVisualStyleBackColor = true;
            this.chkBLMax.Click += new System.EventHandler(this.chkBLMax_Click);
            // 
            // chkBLProm
            // 
            this.chkBLProm.AutoSize = true;
            this.chkBLProm.Location = new System.Drawing.Point(822, 587);
            this.chkBLProm.Name = "chkBLProm";
            this.chkBLProm.Size = new System.Drawing.Size(68, 17);
            this.chkBLProm.TabIndex = 51;
            this.chkBLProm.Text = "L (Prom.)";
            this.chkBLProm.UseVisualStyleBackColor = true;
            this.chkBLProm.Click += new System.EventHandler(this.chkBLProm_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label3.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(1112, 270);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(34, 16);
            this.label3.TabIndex = 50;
            this.label3.Text = "HRS";
            // 
            // txtBUbicacionManoSistema
            // 
            this.txtBUbicacionManoSistema.Location = new System.Drawing.Point(474, 221);
            this.txtBUbicacionManoSistema.Name = "txtBUbicacionManoSistema";
            this.txtBUbicacionManoSistema.Size = new System.Drawing.Size(38, 20);
            this.txtBUbicacionManoSistema.TabIndex = 49;
            // 
            // txtBDistanciaVerticalSistema
            // 
            this.txtBDistanciaVerticalSistema.Location = new System.Drawing.Point(605, 242);
            this.txtBDistanciaVerticalSistema.Name = "txtBDistanciaVerticalSistema";
            this.txtBDistanciaVerticalSistema.Size = new System.Drawing.Size(38, 20);
            this.txtBDistanciaVerticalSistema.TabIndex = 48;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label2.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(523, 239);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(78, 22);
            this.label2.TabIndex = 47;
            this.label2.Text = "vertical";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(523, 217);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(101, 22);
            this.label1.TabIndex = 46;
            this.label1.Text = "Distancia ";
            // 
            // CM
            // 
            this.CM.Location = new System.Drawing.Point(925, 399);
            this.CM.Name = "CM";
            this.CM.Size = new System.Drawing.Size(75, 39);
            this.CM.TabIndex = 45;
            this.CM.Text = "CM";
            this.CM.UseVisualStyleBackColor = true;
            this.CM.Click += new System.EventHandler(this.CM_Click);
            // 
            // btnFM
            // 
            this.btnFM.Location = new System.Drawing.Point(822, 399);
            this.btnFM.Name = "btnFM";
            this.btnFM.Size = new System.Drawing.Size(75, 39);
            this.btnFM.TabIndex = 44;
            this.btnFM.Text = "FM";
            this.btnFM.UseVisualStyleBackColor = true;
            this.btnFM.Click += new System.EventHandler(this.FM_Click);
            // 
            // txtBIndiceElevacionDestino
            // 
            this.txtBIndiceElevacionDestino.Location = new System.Drawing.Point(1077, 724);
            this.txtBIndiceElevacionDestino.Name = "txtBIndiceElevacionDestino";
            this.txtBIndiceElevacionDestino.Size = new System.Drawing.Size(81, 20);
            this.txtBIndiceElevacionDestino.TabIndex = 43;
            // 
            // txtBIndiceElevacionOrigen
            // 
            this.txtBIndiceElevacionOrigen.Location = new System.Drawing.Point(1077, 651);
            this.txtBIndiceElevacionOrigen.Name = "txtBIndiceElevacionOrigen";
            this.txtBIndiceElevacionOrigen.Size = new System.Drawing.Size(81, 20);
            this.txtBIndiceElevacionOrigen.TabIndex = 42;
            // 
            // txtBIndiceElevacionDestinoRWL
            // 
            this.txtBIndiceElevacionDestinoRWL.Location = new System.Drawing.Point(907, 746);
            this.txtBIndiceElevacionDestinoRWL.Name = "txtBIndiceElevacionDestinoRWL";
            this.txtBIndiceElevacionDestinoRWL.Size = new System.Drawing.Size(100, 20);
            this.txtBIndiceElevacionDestinoRWL.TabIndex = 41;
            // 
            // txtBIndiceElevacionOrigenRWL
            // 
            this.txtBIndiceElevacionOrigenRWL.Location = new System.Drawing.Point(907, 674);
            this.txtBIndiceElevacionOrigenRWL.Name = "txtBIndiceElevacionOrigenRWL";
            this.txtBIndiceElevacionOrigenRWL.Size = new System.Drawing.Size(100, 20);
            this.txtBIndiceElevacionOrigenRWL.TabIndex = 40;
            // 
            // txtBIndiceElevacionDestinoPesoObjetoL
            // 
            this.txtBIndiceElevacionDestinoPesoObjetoL.Location = new System.Drawing.Point(907, 709);
            this.txtBIndiceElevacionDestinoPesoObjetoL.Name = "txtBIndiceElevacionDestinoPesoObjetoL";
            this.txtBIndiceElevacionDestinoPesoObjetoL.Size = new System.Drawing.Size(100, 20);
            this.txtBIndiceElevacionDestinoPesoObjetoL.TabIndex = 39;
            // 
            // txtBIndiceElevacionOrigenPesoObjetoL
            // 
            this.txtBIndiceElevacionOrigenPesoObjetoL.Location = new System.Drawing.Point(907, 638);
            this.txtBIndiceElevacionOrigenPesoObjetoL.Name = "txtBIndiceElevacionOrigenPesoObjetoL";
            this.txtBIndiceElevacionOrigenPesoObjetoL.Size = new System.Drawing.Size(100, 20);
            this.txtBIndiceElevacionOrigenPesoObjetoL.TabIndex = 38;
            // 
            // txtBPesoObjetoSistema
            // 
            this.txtBPesoObjetoSistema.Location = new System.Drawing.Point(201, 230);
            this.txtBPesoObjetoSistema.Name = "txtBPesoObjetoSistema";
            this.txtBPesoObjetoSistema.Size = new System.Drawing.Size(49, 20);
            this.txtBPesoObjetoSistema.TabIndex = 35;
            // 
            // txtBDestinoRWL
            // 
            this.txtBDestinoRWL.Location = new System.Drawing.Point(1032, 505);
            this.txtBDestinoRWL.Name = "txtBDestinoRWL";
            this.txtBDestinoRWL.Size = new System.Drawing.Size(77, 20);
            this.txtBDestinoRWL.TabIndex = 32;
            // 
            // txtBOrigenRWL
            // 
            this.txtBOrigenRWL.Location = new System.Drawing.Point(1032, 444);
            this.txtBOrigenRWL.Name = "txtBOrigenRWL";
            this.txtBOrigenRWL.Size = new System.Drawing.Size(77, 20);
            this.txtBOrigenRWL.TabIndex = 31;
            // 
            // txtCMDestino
            // 
            this.txtCMDestino.Location = new System.Drawing.Point(925, 505);
            this.txtCMDestino.Name = "txtCMDestino";
            this.txtCMDestino.Size = new System.Drawing.Size(48, 20);
            this.txtCMDestino.TabIndex = 30;
            // 
            // txtFMDestino
            // 
            this.txtFMDestino.Location = new System.Drawing.Point(832, 505);
            this.txtFMDestino.Name = "txtFMDestino";
            this.txtFMDestino.Size = new System.Drawing.Size(48, 20);
            this.txtFMDestino.TabIndex = 29;
            // 
            // txtBDestinoAM
            // 
            this.txtBDestinoAM.Location = new System.Drawing.Point(740, 505);
            this.txtBDestinoAM.Name = "txtBDestinoAM";
            this.txtBDestinoAM.Size = new System.Drawing.Size(48, 20);
            this.txtBDestinoAM.TabIndex = 28;
            // 
            // txtBDestinoDM
            // 
            this.txtBDestinoDM.Location = new System.Drawing.Point(648, 505);
            this.txtBDestinoDM.Name = "txtBDestinoDM";
            this.txtBDestinoDM.Size = new System.Drawing.Size(48, 20);
            this.txtBDestinoDM.TabIndex = 27;
            // 
            // txtBDestinoVM
            // 
            this.txtBDestinoVM.Location = new System.Drawing.Point(561, 505);
            this.txtBDestinoVM.Name = "txtBDestinoVM";
            this.txtBDestinoVM.Size = new System.Drawing.Size(48, 20);
            this.txtBDestinoVM.TabIndex = 26;
            // 
            // txtBDestinoHM
            // 
            this.txtBDestinoHM.Location = new System.Drawing.Point(474, 505);
            this.txtBDestinoHM.Name = "txtBDestinoHM";
            this.txtBDestinoHM.Size = new System.Drawing.Size(48, 20);
            this.txtBDestinoHM.TabIndex = 25;
            // 
            // txtBDestinoLC
            // 
            this.txtBDestinoLC.Location = new System.Drawing.Point(386, 505);
            this.txtBDestinoLC.Name = "txtBDestinoLC";
            this.txtBDestinoLC.Size = new System.Drawing.Size(48, 20);
            this.txtBDestinoLC.TabIndex = 24;
            // 
            // txtCMOrigen
            // 
            this.txtCMOrigen.Location = new System.Drawing.Point(925, 444);
            this.txtCMOrigen.Name = "txtCMOrigen";
            this.txtCMOrigen.Size = new System.Drawing.Size(48, 20);
            this.txtCMOrigen.TabIndex = 23;
            // 
            // txtFMOrigen
            // 
            this.txtFMOrigen.Location = new System.Drawing.Point(832, 444);
            this.txtFMOrigen.Name = "txtFMOrigen";
            this.txtFMOrigen.Size = new System.Drawing.Size(48, 20);
            this.txtFMOrigen.TabIndex = 22;
            // 
            // txtBOrigenAM
            // 
            this.txtBOrigenAM.Location = new System.Drawing.Point(740, 444);
            this.txtBOrigenAM.Name = "txtBOrigenAM";
            this.txtBOrigenAM.Size = new System.Drawing.Size(48, 20);
            this.txtBOrigenAM.TabIndex = 21;
            // 
            // txtBOrigenDM
            // 
            this.txtBOrigenDM.Location = new System.Drawing.Point(648, 444);
            this.txtBOrigenDM.Name = "txtBOrigenDM";
            this.txtBOrigenDM.Size = new System.Drawing.Size(48, 20);
            this.txtBOrigenDM.TabIndex = 20;
            // 
            // txtBOrigenVM
            // 
            this.txtBOrigenVM.Location = new System.Drawing.Point(561, 444);
            this.txtBOrigenVM.Name = "txtBOrigenVM";
            this.txtBOrigenVM.Size = new System.Drawing.Size(48, 20);
            this.txtBOrigenVM.TabIndex = 19;
            // 
            // txtBOrigenHM
            // 
            this.txtBOrigenHM.Location = new System.Drawing.Point(474, 444);
            this.txtBOrigenHM.Name = "txtBOrigenHM";
            this.txtBOrigenHM.Size = new System.Drawing.Size(48, 20);
            this.txtBOrigenHM.TabIndex = 18;
            // 
            // txtBOrigenLC
            // 
            this.txtBOrigenLC.Location = new System.Drawing.Point(386, 444);
            this.txtBOrigenLC.Name = "txtBOrigenLC";
            this.txtBOrigenLC.Size = new System.Drawing.Size(48, 20);
            this.txtBOrigenLC.TabIndex = 17;
            // 
            // txtBAcoplamientoObjetos
            // 
            this.txtBAcoplamientoObjetos.Location = new System.Drawing.Point(1184, 301);
            this.txtBAcoplamientoObjetos.Name = "txtBAcoplamientoObjetos";
            this.txtBAcoplamientoObjetos.Size = new System.Drawing.Size(96, 20);
            this.txtBAcoplamientoObjetos.TabIndex = 16;
            // 
            // txtBDuracion
            // 
            this.txtBDuracion.Location = new System.Drawing.Point(1094, 301);
            this.txtBDuracion.Name = "txtBDuracion";
            this.txtBDuracion.Size = new System.Drawing.Size(74, 20);
            this.txtBDuracion.TabIndex = 15;
            // 
            // txtBFrecuencia
            // 
            this.txtBFrecuencia.Location = new System.Drawing.Point(938, 301);
            this.txtBFrecuencia.Name = "txtBFrecuencia";
            this.txtBFrecuencia.Size = new System.Drawing.Size(139, 20);
            this.txtBFrecuencia.TabIndex = 14;
            // 
            // txtBAnguloAsimetricoDestinoA
            // 
            this.txtBAnguloAsimetricoDestinoA.Location = new System.Drawing.Point(810, 301);
            this.txtBAnguloAsimetricoDestinoA.Name = "txtBAnguloAsimetricoDestinoA";
            this.txtBAnguloAsimetricoDestinoA.Size = new System.Drawing.Size(103, 20);
            this.txtBAnguloAsimetricoDestinoA.TabIndex = 13;
            // 
            // txtBAnguloAsimetricoOrigenA
            // 
            this.txtBAnguloAsimetricoOrigenA.Location = new System.Drawing.Point(664, 301);
            this.txtBAnguloAsimetricoOrigenA.Name = "txtBAnguloAsimetricoOrigenA";
            this.txtBAnguloAsimetricoOrigenA.Size = new System.Drawing.Size(115, 20);
            this.txtBAnguloAsimetricoOrigenA.TabIndex = 12;
            // 
            // txtBUbicacionManoDestinoV
            // 
            this.txtBUbicacionManoDestinoV.Location = new System.Drawing.Point(459, 301);
            this.txtBUbicacionManoDestinoV.Name = "txtBUbicacionManoDestinoV";
            this.txtBUbicacionManoDestinoV.Size = new System.Drawing.Size(48, 20);
            this.txtBUbicacionManoDestinoV.TabIndex = 11;
            // 
            // txtBUbicacionManoDestinoH
            // 
            this.txtBUbicacionManoDestinoH.Location = new System.Drawing.Point(395, 301);
            this.txtBUbicacionManoDestinoH.Name = "txtBUbicacionManoDestinoH";
            this.txtBUbicacionManoDestinoH.Size = new System.Drawing.Size(48, 20);
            this.txtBUbicacionManoDestinoH.TabIndex = 10;
            // 
            // txtBUbicacionManoOrigenV
            // 
            this.txtBUbicacionManoOrigenV.Location = new System.Drawing.Point(330, 301);
            this.txtBUbicacionManoOrigenV.Name = "txtBUbicacionManoOrigenV";
            this.txtBUbicacionManoOrigenV.Size = new System.Drawing.Size(59, 20);
            this.txtBUbicacionManoOrigenV.TabIndex = 9;
            // 
            // txtBUbicacionManoOrigenH
            // 
            this.txtBUbicacionManoOrigenH.Location = new System.Drawing.Point(266, 301);
            this.txtBUbicacionManoOrigenH.Name = "txtBUbicacionManoOrigenH";
            this.txtBUbicacionManoOrigenH.Size = new System.Drawing.Size(58, 20);
            this.txtBUbicacionManoOrigenH.TabIndex = 8;
            // 
            // txtBDistanciaVerticalD
            // 
            this.txtBDistanciaVerticalD.Location = new System.Drawing.Point(527, 301);
            this.txtBDistanciaVerticalD.Name = "txtBDistanciaVerticalD";
            this.txtBDistanciaVerticalD.Size = new System.Drawing.Size(116, 20);
            this.txtBDistanciaVerticalD.TabIndex = 7;
            // 
            // txtBPesoObjetoLMax
            // 
            this.txtBPesoObjetoLMax.Location = new System.Drawing.Point(171, 301);
            this.txtBPesoObjetoLMax.Name = "txtBPesoObjetoLMax";
            this.txtBPesoObjetoLMax.Size = new System.Drawing.Size(79, 20);
            this.txtBPesoObjetoLMax.TabIndex = 6;
            // 
            // txtBPesoObjetoLProm
            // 
            this.txtBPesoObjetoLProm.Location = new System.Drawing.Point(55, 301);
            this.txtBPesoObjetoLProm.Name = "txtBPesoObjetoLProm";
            this.txtBPesoObjetoLProm.Size = new System.Drawing.Size(93, 20);
            this.txtBPesoObjetoLProm.TabIndex = 5;
            // 
            // txtBDescripcionDelTrabajo
            // 
            this.txtBDescripcionDelTrabajo.Location = new System.Drawing.Point(810, 84);
            this.txtBDescripcionDelTrabajo.Multiline = true;
            this.txtBDescripcionDelTrabajo.Name = "txtBDescripcionDelTrabajo";
            this.txtBDescripcionDelTrabajo.Size = new System.Drawing.Size(415, 72);
            this.txtBDescripcionDelTrabajo.TabIndex = 4;
            // 
            // txtBFecha
            // 
            this.txtBFecha.Location = new System.Drawing.Point(277, 136);
            this.txtBFecha.Name = "txtBFecha";
            this.txtBFecha.Size = new System.Drawing.Size(397, 20);
            this.txtBFecha.TabIndex = 3;
            // 
            // txtBNombreAnalista
            // 
            this.txtBNombreAnalista.Location = new System.Drawing.Point(277, 110);
            this.txtBNombreAnalista.Name = "txtBNombreAnalista";
            this.txtBNombreAnalista.Size = new System.Drawing.Size(397, 20);
            this.txtBNombreAnalista.TabIndex = 2;
            // 
            // txtBTituloProfesional
            // 
            this.txtBTituloProfesional.Location = new System.Drawing.Point(277, 84);
            this.txtBTituloProfesional.Name = "txtBTituloProfesional";
            this.txtBTituloProfesional.Size = new System.Drawing.Size(397, 20);
            this.txtBTituloProfesional.TabIndex = 1;
            // 
            // txtBDepartamento
            // 
            this.txtBDepartamento.Location = new System.Drawing.Point(277, 58);
            this.txtBDepartamento.Name = "txtBDepartamento";
            this.txtBDepartamento.Size = new System.Drawing.Size(397, 20);
            this.txtBDepartamento.TabIndex = 0;
            // 
            // btnCalcularResultado
            // 
            this.btnCalcularResultado.Location = new System.Drawing.Point(848, 12);
            this.btnCalcularResultado.Name = "btnCalcularResultado";
            this.btnCalcularResultado.Size = new System.Drawing.Size(125, 23);
            this.btnCalcularResultado.TabIndex = 3;
            this.btnCalcularResultado.Text = "Calcular Resultado";
            this.btnCalcularResultado.UseVisualStyleBackColor = true;
            this.btnCalcularResultado.Click += new System.EventHandler(this.btnCalcularResultado_Click);
            // 
            // btnRefrescar
            // 
            this.btnRefrescar.Location = new System.Drawing.Point(415, 12);
            this.btnRefrescar.Name = "btnRefrescar";
            this.btnRefrescar.Size = new System.Drawing.Size(92, 23);
            this.btnRefrescar.TabIndex = 4;
            this.btnRefrescar.Text = "Refrescar Datos";
            this.btnRefrescar.UseVisualStyleBackColor = true;
            this.btnRefrescar.Click += new System.EventHandler(this.btnRefrescar_Click);
            // 
            // btnInvertir
            // 
            this.btnInvertir.Location = new System.Drawing.Point(245, 12);
            this.btnInvertir.Name = "btnInvertir";
            this.btnInvertir.Size = new System.Drawing.Size(156, 23);
            this.btnInvertir.TabIndex = 7;
            this.btnInvertir.Text = "Invertir Valores del Sistema";
            this.btnInvertir.UseVisualStyleBackColor = true;
            this.btnInvertir.Click += new System.EventHandler(this.btnInvertir_Click);
            // 
            // chkBSistemaInternacional
            // 
            this.chkBSistemaInternacional.AutoSize = true;
            this.chkBSistemaInternacional.Location = new System.Drawing.Point(12, 18);
            this.chkBSistemaInternacional.Name = "chkBSistemaInternacional";
            this.chkBSistemaInternacional.Size = new System.Drawing.Size(127, 17);
            this.chkBSistemaInternacional.TabIndex = 51;
            this.chkBSistemaInternacional.Text = "Sistema Internacional";
            this.chkBSistemaInternacional.UseVisualStyleBackColor = true;
            this.chkBSistemaInternacional.Click += new System.EventHandler(this.chkBSistemaInternacional_Click);
            // 
            // chkBSistemaIngles
            // 
            this.chkBSistemaIngles.AutoSize = true;
            this.chkBSistemaIngles.Location = new System.Drawing.Point(145, 18);
            this.chkBSistemaIngles.Name = "chkBSistemaIngles";
            this.chkBSistemaIngles.Size = new System.Drawing.Size(94, 17);
            this.chkBSistemaIngles.TabIndex = 52;
            this.chkBSistemaIngles.Text = "Sistema Ingles";
            this.chkBSistemaIngles.UseVisualStyleBackColor = true;
            this.chkBSistemaIngles.Click += new System.EventHandler(this.chkBSistemaIngles_Click);
            // 
            // btnLimpiar
            // 
            this.btnLimpiar.Location = new System.Drawing.Point(513, 12);
            this.btnLimpiar.Name = "btnLimpiar";
            this.btnLimpiar.Size = new System.Drawing.Size(75, 23);
            this.btnLimpiar.TabIndex = 53;
            this.btnLimpiar.Text = "Limpiar Hoja";
            this.btnLimpiar.UseVisualStyleBackColor = true;
            this.btnLimpiar.Click += new System.EventHandler(this.btnLimpiar_Click);
            // 
            // botonGuardarExcel
            // 
            this.botonGuardarExcel.Location = new System.Drawing.Point(987, 12);
            this.botonGuardarExcel.Name = "botonGuardarExcel";
            this.botonGuardarExcel.Size = new System.Drawing.Size(159, 23);
            this.botonGuardarExcel.TabIndex = 54;
            this.botonGuardarExcel.Text = "Guardar Resultados en excel";
            this.botonGuardarExcel.UseVisualStyleBackColor = true;
            this.botonGuardarExcel.Click += new System.EventHandler(this.botonGuardarExcel_Click);
            // 
            // HojaDeTrabajoNiosh
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(1350, 749);
            this.Controls.Add(this.botonGuardarExcel);
            this.Controls.Add(this.btnLimpiar);
            this.Controls.Add(this.chkBSistemaIngles);
            this.Controls.Add(this.chkBSistemaInternacional);
            this.Controls.Add(this.btnInvertir);
            this.Controls.Add(this.btnRefrescar);
            this.Controls.Add(this.btnCalcularResultado);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.BotonGuardarImagen);
            this.Name = "HojaDeTrabajoNiosh";
            this.Text = "Metodo NIOSH";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.HojaDeTrabajoNiosh_FormClosing);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button BotonGuardarImagen;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txtBDescripcionDelTrabajo;
        private System.Windows.Forms.TextBox txtBFecha;
        private System.Windows.Forms.TextBox txtBNombreAnalista;
        private System.Windows.Forms.TextBox txtBTituloProfesional;
        private System.Windows.Forms.TextBox txtBDepartamento;
        private System.Windows.Forms.TextBox txtBAcoplamientoObjetos;
        private System.Windows.Forms.TextBox txtBDuracion;
        private System.Windows.Forms.TextBox txtBFrecuencia;
        private System.Windows.Forms.TextBox txtBAnguloAsimetricoDestinoA;
        private System.Windows.Forms.TextBox txtBAnguloAsimetricoOrigenA;
        private System.Windows.Forms.TextBox txtBUbicacionManoDestinoV;
        private System.Windows.Forms.TextBox txtBUbicacionManoDestinoH;
        private System.Windows.Forms.TextBox txtBUbicacionManoOrigenV;
        private System.Windows.Forms.TextBox txtBUbicacionManoOrigenH;
        private System.Windows.Forms.TextBox txtBDistanciaVerticalD;
        private System.Windows.Forms.TextBox txtBPesoObjetoLMax;
        private System.Windows.Forms.TextBox txtBPesoObjetoLProm;
        private System.Windows.Forms.TextBox txtBPesoObjetoSistema;
        private System.Windows.Forms.TextBox txtBDestinoRWL;
        private System.Windows.Forms.TextBox txtBOrigenRWL;
        private System.Windows.Forms.TextBox txtCMDestino;
        private System.Windows.Forms.TextBox txtFMDestino;
        private System.Windows.Forms.TextBox txtBDestinoAM;
        private System.Windows.Forms.TextBox txtBDestinoDM;
        private System.Windows.Forms.TextBox txtBDestinoVM;
        private System.Windows.Forms.TextBox txtBDestinoHM;
        private System.Windows.Forms.TextBox txtBDestinoLC;
        private System.Windows.Forms.TextBox txtBOrigenAM;
        private System.Windows.Forms.TextBox txtBOrigenDM;
        private System.Windows.Forms.TextBox txtBOrigenVM;
        private System.Windows.Forms.TextBox txtBOrigenHM;
        private System.Windows.Forms.TextBox txtBOrigenLC;
        private System.Windows.Forms.TextBox txtBIndiceElevacionDestino;
        private System.Windows.Forms.TextBox txtBIndiceElevacionOrigen;
        private System.Windows.Forms.TextBox txtBIndiceElevacionDestinoRWL;
        private System.Windows.Forms.TextBox txtBIndiceElevacionOrigenRWL;
        private System.Windows.Forms.TextBox txtBIndiceElevacionDestinoPesoObjetoL;
        private System.Windows.Forms.TextBox txtBIndiceElevacionOrigenPesoObjetoL;
        private System.Windows.Forms.Button btnCalcularResultado;
        private System.Windows.Forms.Button CM;
        private System.Windows.Forms.Button btnFM;
        public System.Windows.Forms.TextBox txtCMOrigen;
        public System.Windows.Forms.TextBox txtFMOrigen;
        private System.Windows.Forms.Button btnRefrescar;
        private System.Windows.Forms.TextBox txtBUbicacionManoSistema;
        private System.Windows.Forms.TextBox txtBDistanciaVerticalSistema;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnInvertir;
        private System.Windows.Forms.CheckBox chkBSistemaInternacional;
        private System.Windows.Forms.CheckBox chkBSistemaIngles;
        private System.Windows.Forms.Button btnLimpiar;
        private System.Windows.Forms.CheckBox chkBLMax;
        private System.Windows.Forms.CheckBox chkBLProm;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
        private System.Windows.Forms.Button btnVM;
        private System.Windows.Forms.Button btnDM;
        private System.Windows.Forms.Button btnAM;
        private System.Windows.Forms.Button btnHM;
        private System.Windows.Forms.Button btnLC;
        private System.Windows.Forms.Button btnA;
        private System.Windows.Forms.Button btnD;
        private System.Windows.Forms.Button btnV;
        private System.Windows.Forms.Button btnH;
        private System.Windows.Forms.Button btnL;
        private System.Windows.Forms.ComboBox comboBoxRWLDestino;
        private System.Windows.Forms.ComboBox comboBoxRWLOrigen;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button botonGuardarExcel;
    }
}

